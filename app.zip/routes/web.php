<?php

use App\Http\Controllers\Backend\AdminsController;
use App\Http\Controllers\Backend\Auth\ForgotPasswordController;
use App\Http\Controllers\Backend\Auth\LoginController;
use App\Http\Controllers\Backend\CentralPointController;
use App\Http\Controllers\Backend\DashboardController;
use App\Http\Controllers\Backend\DealerController;
use App\Http\Controllers\Backend\RetailerController;
use App\Http\Controllers\Backend\RolesController;
use App\Http\Controllers\MapAnalyticsController;
use App\Http\Controllers\TestController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Auth::routes();

Route::get('/', 'HomeController@redirectAdmin')->name('index');
Route::get('/home', 'HomeController@index')->name('home');

/**
 * Admin routes
 */
Route::get('/barikoi/autocomplete', [App\Http\Controllers\BarikoiController::class, 'autocomplete']);

Route::group(['prefix' => 'admin', 'as' => 'admin.'], function () {
    Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
    Route::resource('roles', RolesController::class);
    Route::resource('admins', AdminsController::class);

    // Login Routes.
    Route::get('/login', [LoginController::class, 'showLoginForm'])->name('login');
    Route::post('/login/submit', [LoginController::class, 'login'])->name('login.submit');

    // Logout Routes.
    Route::post('/logout/submit', [LoginController::class, 'logout'])->name('logout.submit');

    // Forget Password Routes.
    Route::get('/password/reset', [ForgotPasswordController::class, 'showLinkRequestForm'])->name('password.request');
    Route::post('/password/reset/submit', [ForgotPasswordController::class, 'reset'])->name('password.update');

    //Dealer
    Route::get('dealers/import-show', [DealerController::class, 'importShow'])->name('dealers.import-show');
    Route::post('dealers/import', [DealerController::class, 'import'])->name('dealers.import');
    Route::get('dealers/sample-excel', [DealerController::class, 'export'])->name('dealers.sample-excel');
    Route::resource('dealers', DealerController::class)->except(['show']);
    Route::get('all-dealers', [DealerController::class,'allDealers'])->name('allDealers');
    //Retailer
    Route::resource('retailers', RetailerController::class)->except(['show']);
    Route::get('retailers/import-show', [RetailerController::class, 'importShow'])->name('retailers.import-show');
    Route::post('retailers/import', [RetailerController::class, 'import'])->name('retailers.import');
    Route::get('retailers/sample-excel', [RetailerController::class, 'export'])->name('retailers.sample-excel');
    Route::get('all-retailers', [RetailerController::class,'allDealers'])->name('allRetailers');
    Route::get('map-analytics', [MapAnalyticsController::class, 'mapAnalytics'])->name('map.analytics');
    Route::resource('central-points',CentralPointController::class);
})->middleware('auth:admin');
Route::get('/test',[TestController::class,'index'])->name('test');
//Route::get('/api/proxy/autocomplete', [ApiProxyController::class, 'fetchAutocomplete']);

