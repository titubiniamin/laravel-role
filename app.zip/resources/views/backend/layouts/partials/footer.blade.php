
<!-- footer area start-->
<footer>
    <div class="footer-area">
        <p>© Copyright 2024. All right reserved. <a href="https://omnilabes.com/">Omnilab Enterprise Solutions Ltd.</a>.</p>
    </div>
</footer>
<!-- footer area end-->
